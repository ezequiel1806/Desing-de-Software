# Respostas das questoes 1 - 9

---

## Pergunta 1

O que muda na saída quando você escolhe Escola Pública ou Escola Privada?

## Resposta:

Muda o tipo de professor, ensino, material e avaliação apresentados. Cada opção mostra as características do tipo de escola escolhido.

---

## Pergunta 2

Por que usar `MaterialEscolaPrivada` dentro de `EscolaTecnicaFactory` não é adequado?

## Resposta:

Porque a fábrica da escola técnica deveria usar o material da escola técnica, e não o da escola privada.

---

## Pergunta 3

O Java necessariamente apresentará erro de compilação ou esse é principalmente um erro de projeto/design?

## Resposta:

O código pode compilar normalmente, porque `MaterialEscolaPrivada` implementa `MaterialDidatico`. O problema é mais na organização do projeto.

---

## Pergunta 4

Como corrigir o método `criarMaterialDidatico`?

## Resposta:

```java
@Override
public MaterialDidatico criarMaterialDidatico() {
    return new MaterialEscolaTecnica();
}
```

---

## Pergunta 5

Qual é a função da interface `EscolaFactory`?

## Resposta:

A função dela é definir os métodos que devem ser usados pelas fábricas de cada tipo de escola.

---

## Pergunta 6

Qual é a diferença entre `EscolaFactory` e `EscolaTecnicaFactory`?

## Resposta:

A `EscolaFactory` define como as fábricas devem funcionar, enquanto a `EscolaTecnicaFactory` cria os objetos específicos da escola técnica.

---

## Pergunta 7

Por que `SalaDeAula` não precisa saber se está trabalhando com uma escola pública, privada ou técnica?

## Resposta:

Porque quem cria os objetos de cada tipo de escola é a fábrica. Assim, a `SalaDeAula` pode funcionar da mesma forma para todas elas.

---

## Pergunta 8

Qual vantagem existe em programar usando a interface `Professor`?

## Resposta:

A vantagem é poder usar diferentes tipos de professor sem precisar mudar o funcionamento principal do programa.

---

## Pergunta 9

Ao acrescentar `EscolaTecnicaFactory`, foi necessário modificar `SalaDeAula`? O que isso demonstra sobre o Abstract Factory?

## Resposta:

Não foi necessário. Isso mostra que o Abstract Factory permite adicionar novos tipos de escola sem precisar alterar a `SalaDeAula`.